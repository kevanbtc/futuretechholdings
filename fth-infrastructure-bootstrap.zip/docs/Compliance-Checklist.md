# Compliance & Policy Checklist (Private Placement)

- Invite-only gating; KYC SBT with jurisdiction/accreditation; sanctions screening.
- PPM, fee schedule, redemption policy notarized on IPFS (SystemRegistry to host CIDs).
