# QA, Invariants, and Acceptance Tests

- Unit: KYC SBT, StakeLocker lifecycle, PoR coverage, token math, RBAC.
- Invariants: coverage >= threshold; supply accounting; NAV bounds (price adapter to add).
- E2E: golden path + emergency pause; jurisdiction toggles.
