# Pre-Launch Security Checklist

- Gnosis Safe roles; 48–72h timelock for high-risk changes.
- Reentrancy guards; module & global pause wired.
- Oracle sanity (staleness/deviation/quorum) → auto-pause.
- Coverage guard ≥100% (recommend 125% initial).
