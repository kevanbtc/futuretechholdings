# FTH-G: Private, Asset-Backed Gold Program (CEO Brief)

- Private, invite-only; 1 token (FTH-G) = 1 kg vaulted LBMA gold (DMCC).
- Client flow: Invite → KYC SBT → USDT stake (5 mo) → auto-convert to 1 kg FTH-G → monthly distributions → redeem (USDT or 1 kg bar).
- Assurances: Live PoR, multisig + timelock, program caps, insurance, pause switch.
