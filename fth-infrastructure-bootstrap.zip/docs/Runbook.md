# Operations Runbook (Condensed)

- Onboard → Stake → Convert → Distribute → Redeem.
- Pause on oracle/coverage incidents; resume after verification.
